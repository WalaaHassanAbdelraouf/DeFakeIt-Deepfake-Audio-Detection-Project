package com.example.defakeit

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
